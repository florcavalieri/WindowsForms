﻿
namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    partial class MENU
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MENU));
            this.btnBuscarSoluciones = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.AJEDREZ = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Florci = new System.Windows.Forms.Label();
            this.Tini = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnPODA = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBuscarSoluciones
            // 
            this.btnBuscarSoluciones.BackColor = System.Drawing.Color.Maroon;
            this.btnBuscarSoluciones.Font = new System.Drawing.Font("Nasalization", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarSoluciones.ForeColor = System.Drawing.Color.White;
            this.btnBuscarSoluciones.Location = new System.Drawing.Point(215, 337);
            this.btnBuscarSoluciones.Name = "btnBuscarSoluciones";
            this.btnBuscarSoluciones.Size = new System.Drawing.Size(151, 39);
            this.btnBuscarSoluciones.TabIndex = 0;
            this.btnBuscarSoluciones.Text = "BUSCAR SOLUCIONES";
            this.btnBuscarSoluciones.UseVisualStyleBackColor = false;
            this.btnBuscarSoluciones.Click += new System.EventHandler(this.btnBuscarSoluciones_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.Maroon;
            this.btnSalir.Font = new System.Drawing.Font("Nasalization", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.Red;
            this.btnSalir.Location = new System.Drawing.Point(780, 439);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(106, 41);
            this.btnSalir.TabIndex = 1;
            this.btnSalir.Text = "SALIR";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // AJEDREZ
            // 
            this.AJEDREZ.BackColor = System.Drawing.Color.Black;
            this.AJEDREZ.Font = new System.Drawing.Font("Nasalization", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AJEDREZ.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.AJEDREZ.Location = new System.Drawing.Point(292, 9);
            this.AJEDREZ.Name = "AJEDREZ";
            this.AJEDREZ.Size = new System.Drawing.Size(480, 80);
            this.AJEDREZ.TabIndex = 2;
            this.AJEDREZ.Text = "AJEDREZ";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.White;
            this.comboBox1.Font = new System.Drawing.Font("Nasalization", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.ForeColor = System.Drawing.Color.Black;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "5",
            "10"});
            this.comboBox1.Location = new System.Drawing.Point(215, 283);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(129, 30);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Maroon;
            this.label1.Font = new System.Drawing.Font("Nasalization", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(211, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(473, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "CANTIDAD DE SOLUCIONES A BUSCAR: ";
            // 
            // Florci
            // 
            this.Florci.AutoSize = true;
            this.Florci.Font = new System.Drawing.Font("Nasalization", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Florci.ForeColor = System.Drawing.Color.Yellow;
            this.Florci.Location = new System.Drawing.Point(131, 98);
            this.Florci.Name = "Florci";
            this.Florci.Size = new System.Drawing.Size(235, 18);
            this.Florci.TabIndex = 5;
            this.Florci.Text = "Florencia Cavalieri";
            // 
            // Tini
            // 
            this.Tini.AutoSize = true;
            this.Tini.Font = new System.Drawing.Font("Nasalization", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tini.ForeColor = System.Drawing.Color.Yellow;
            this.Tini.Location = new System.Drawing.Point(646, 98);
            this.Tini.Name = "Tini";
            this.Tini.Size = new System.Drawing.Size(213, 18);
            this.Tini.TabIndex = 6;
            this.Tini.Text = "Santina Espósito ";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.Font = new System.Drawing.Font("Nasalization", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(612, 376);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 44);
            this.button1.TabIndex = 7;
            this.button1.Text = "Cálculo del costo";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnPODA
            // 
            this.btnPODA.BackColor = System.Drawing.Color.Maroon;
            this.btnPODA.Font = new System.Drawing.Font("Nasalization", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPODA.ForeColor = System.Drawing.Color.White;
            this.btnPODA.Location = new System.Drawing.Point(612, 426);
            this.btnPODA.Name = "btnPODA";
            this.btnPODA.Size = new System.Drawing.Size(121, 42);
            this.btnPODA.TabIndex = 8;
            this.btnPODA.Text = "Criterios de Poda";
            this.btnPODA.UseVisualStyleBackColor = false;
            this.btnPODA.Click += new System.EventHandler(this.btnPODA_Click);
            // 
            // MENU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(977, 492);
            this.Controls.Add(this.btnPODA);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Tini);
            this.Controls.Add(this.Florci);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.AJEDREZ);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnBuscarSoluciones);
            this.DoubleBuffered = true;
            this.Name = "MENU";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBuscarSoluciones;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Label AJEDREZ;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Florci;
        private System.Windows.Forms.Label Tini;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnPODA;
    }
}

