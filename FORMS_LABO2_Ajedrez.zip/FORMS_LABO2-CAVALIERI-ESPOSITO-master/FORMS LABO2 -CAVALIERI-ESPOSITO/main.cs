﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    class main
    {
        /*static void Main(string[] args)
        {

            cReina REINA = new cReina();
            cRey REY = new cRey();
            cTorre_Blanco TORRE_B = new cTorre_Blanco();
            cTorre_Negro TORRE_N = new cTorre_Negro();
            cAlfil_Blanco ALFIL_B = new cAlfil_Blanco();
            cAlfil_Negro ALFIL_N = new cAlfil_Negro();
            cCaballo_Blanco CABALLO_B = new cCaballo_Blanco();
            cCaballo_Negro CABALLO_N = new cCaballo_Negro();



            matriz tablero_aux = new matriz(8);
            matriz tableroATAQUES = new matriz(8);

            //pongo todo en 0
            tablero_aux.inicializo(8);
            tableroATAQUES.inicializo(8);


            int cont_soluciones_encontradas = 0;   //cantidad de soluciones encontradas distintas 


            //CREO LISTA DE SOLUCIONES Y LE AGREGO LAS DOS SOLUCIONES INICIALES
            List<matriz> lista_soluciones = new List<matriz>();

            for (int i = 0; i < 10; i++)
                lista_soluciones.Add(new matriz(8));


            //----------------------------------solucion 1----------------------------------------------

            lista_soluciones[0].ubico_piezas(1);   //agrego la primera solucion a la lista
            cont_soluciones_encontradas++;
            lista_soluciones[0].AtaqueFATAL(lista_soluciones[0]);  //agrego en la misma posicion el tablero con ataques

            Console.Write("solucion " + cont_soluciones_encontradas + "\n\n");
            lista_soluciones[0].imprimirTablero(); //tablero con soluciones

            //---------------------------------------------------------------------------------------------



            //----------------------------------solucion 2----------------------------------------------

            lista_soluciones[1].ubico_piezas(2);
            cont_soluciones_encontradas++;
            lista_soluciones[1].AtaqueFATAL(lista_soluciones[1]);

            Console.Write("solucion " + cont_soluciones_encontradas + "\n\n");
            lista_soluciones[1].imprimirTablero(); //tablero con soluciones

            //---------------------------------------------------------------------------------------------


            //--------------------------------------COMIENZA EL ATAQUE---------------------------------------------

            //Inicializo el tablero en alguna solucion y luego empiezo a mover
            Random r = new Random();
            int sol = (int)r.Next(1, 3);
            tablero_aux.ubico_piezas(sol);

            while (cont_soluciones_encontradas < 10) // se hace hasta que haya 10 soluciones distintas
            {

                matriz.eReferencia tipo;
                tipo = matriz.eReferencia.rey;
                bool found_sol = false; //BRUNO


                do
                {
                    switch (tipo)
                    {
                        case matriz.eReferencia.rey:
                            REY.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.torreB:
                            TORRE_B.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;
                        case matriz.eReferencia.torreN:
                            TORRE_N.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.caballoB:
                            CABALLO_B.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.caballoN:
                            CABALLO_N.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.alfilB:
                            ALFIL_B.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.alfilN:
                            ALFIL_N.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.reina:
                            REINA.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        default:
                            tipo = matriz.eReferencia.rey;
                            break;
                    }

                } while (!found_sol);

                //si la solución es válida la guardo y sumo 1 al contador de soluciones
                cont_soluciones_encontradas++;

                lista_soluciones[cont_soluciones_encontradas - 1] = tablero_aux;

                lista_soluciones[cont_soluciones_encontradas - 1].AtaqueFATAL(lista_soluciones[cont_soluciones_encontradas - 1]);

                Console.Write("   solucion " + cont_soluciones_encontradas + "\n\n");

                lista_soluciones[cont_soluciones_encontradas - 1].imprimirTablero(); //tablero con soluciones
                                                                                     
                // busco otra sol de la cual partir
                tablero_aux = new matriz(8);
                r = new Random();
                sol = (int)r.Next(1, 3);
                tablero_aux.ubico_piezas(sol);


            }
            Console.ReadLine();
        }*/
    }
}
