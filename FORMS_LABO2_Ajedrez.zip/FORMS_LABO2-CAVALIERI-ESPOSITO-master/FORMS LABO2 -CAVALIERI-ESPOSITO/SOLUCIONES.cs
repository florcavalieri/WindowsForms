﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    public partial class SOLUCIONES : Form
    {
        MENU llamado;
        List<matriz> Lista_Soluciones;
        int CANT_SOLUCIONES_BUSCAR;
        public SOLUCIONES(List<matriz> Lista_Soluciones_, MENU llamado_, int comboBox)
        {
            InitializeComponent();
            llamado = llamado_;
            Lista_Soluciones = Lista_Soluciones_;
            dataGridView1.InitializeLifetimeService();
            dataGridViewAtaques.InitializeLifetimeService();
            btnSiguienteSolucion.Visible = true;
            btnVolverMenu.Visible = true;
            btnSalir.Visible = true;
            CANT_SOLUCIONES_BUSCAR = comboBox;
            Imprimir(Lista_Soluciones);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void btnVolverMenu_Click(object sender, EventArgs e)
        {
            MENU FormMENU = new MENU();
            FormMENU.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        { }

        private void Imprimir(List<matriz> Lista_Soluciones)
        {

            if (progressBar.Value < CANT_SOLUCIONES_BUSCAR)
            {
                btnSiguienteSolucion.Visible = true;

                
                dataGridView1.RowTemplate.Height = 50;
                dataGridViewAtaques.RowTemplate.Height = 50;

                //Limpiar tablero
                if (progressBar.Value != 0)
                {
                    dataGridView1.Rows.Clear();
                    dataGridView1.Refresh();
                    dataGridViewAtaques.Rows.Clear();
                    dataGridViewAtaques.Refresh();
                }
            }


            dataGridView1.ColumnCount = 8;
            dataGridView1.RowCount = 8;
            dataGridViewAtaques.ColumnCount = 8;
            dataGridViewAtaques.RowCount = 8;



            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    //--------------------------------------------------------------------
                    //-----------------------TABLERO PIEZAS-------------------------------
                    //--------------------------------------------------------------------

                    DataGridViewImageCell imagen_celda = new DataGridViewImageCell();
                    

                    if ((i + j) % 2 == 0 || (i + j) == 0) //si la casilla[i,j] es par
                        imagen_celda.Style.BackColor = Color.LightGray;
                    else //si es impar
                        imagen_celda.Style.BackColor = Color.Maroon;
                    if (Lista_Soluciones[progressBar.Value].tablero[i, j] == (int)matriz.eReferencia.desocupado)
                        imagen_celda.Value = (Bitmap)Image.FromFile("TRANSPARENTE.png");
                    if (Lista_Soluciones[progressBar.Value].tablero[i, j] == (int)matriz.eReferencia.rey)
                        imagen_celda.Value = (Bitmap)Image.FromFile("Black_King.png");
                    if (Lista_Soluciones[progressBar.Value].tablero[i, j] == (int)matriz.eReferencia.torreB)
                        imagen_celda.Value = (Bitmap)Image.FromFile("White_Rook.png");
                    if (Lista_Soluciones[progressBar.Value].tablero[i, j] == (int)matriz.eReferencia.torreN)
                        imagen_celda.Value = (Bitmap)Image.FromFile("Black_Rook.png");
                    if (Lista_Soluciones[progressBar.Value].tablero[i, j] == (int)matriz.eReferencia.caballoB)
                        imagen_celda.Value = (Bitmap)Image.FromFile("White_Knight.png");
                    if (Lista_Soluciones[progressBar.Value].tablero[i, j] == (int)matriz.eReferencia.caballoN)
                        imagen_celda.Value = (Bitmap)Image.FromFile("Black_Knight.png");
                    if (Lista_Soluciones[progressBar.Value].tablero[i, j] == (int)matriz.eReferencia.alfilB)
                        imagen_celda.Value = (Bitmap)Image.FromFile("White_Bishop.png");
                    if (Lista_Soluciones[progressBar.Value].tablero[i, j] == (int)matriz.eReferencia.alfilN)
                        imagen_celda.Value = (Bitmap)Image.FromFile("Black_Bishop.png");
                    if (Lista_Soluciones[progressBar.Value].tablero[i, j] == (int)matriz.eReferencia.reina)
                        imagen_celda.Value = (Bitmap)Image.FromFile("Black_Queen.png");

                    dataGridView1[i, j] = imagen_celda;
                }
            }

            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    //--------------------------------------------------------------------
                    //-----------------------TABLERO ATAQUES------------------------------
                    //--------------------------------------------------------------------

                    DataGridViewImageCell imagen_celda_ataque = new DataGridViewImageCell();
                    if ((i + j) % 2 == 0 || (i + j) == 0) //si la casilla[i,j] es par
                    {
                        if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] != (int)matriz.eReferencia.FATAL
                            && Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] != (int)matriz.eReferencia.LEVE)
                            imagen_celda_ataque.Style.BackColor = Color.LightGray;
                    }
                    else //si es impar
                    {
                        if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] != (int)matriz.eReferencia.FATAL
                          && Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] != (int)matriz.eReferencia.LEVE)
                            imagen_celda_ataque.Style.BackColor = Color.Maroon;
                    }
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.rey)
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("Black_King.png");
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.torreB)
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("White_Rook.png");
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.torreN)
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("Black_Rook.png");
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.caballoB)
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("White_Knight.png");
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.caballoN)
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("Black_Knight.png");
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.alfilB)
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("White_Bishop.png");
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.alfilN)
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("Black_Bishop.png");
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.reina)
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("Black_Queen.png");
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.desocupado) //LEVE
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("LEVE.png");
                    if (Lista_Soluciones[progressBar.Value].tablero_ataque[i, j] == (int)matriz.eReferencia.FATAL)
                        imagen_celda_ataque.Value = (Bitmap)Image.FromFile("FATAL.png");

                    dataGridViewAtaques[i, j] = imagen_celda_ataque;
                }
            }


            progressBar.Increment(1);


            if (progressBar.Value == CANT_SOLUCIONES_BUSCAR) //si ya se imprimieron todas las soluciones
                btnSiguienteSolucion.Visible = false;
           
            
        }

        private void btnSiguienteSolucion_Click(object sender, EventArgs e)
        {
            Imprimir(Lista_Soluciones);
        }
    }
}
