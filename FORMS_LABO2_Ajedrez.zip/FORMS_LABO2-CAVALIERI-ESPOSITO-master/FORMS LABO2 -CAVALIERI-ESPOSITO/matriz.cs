﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    public class matriz
    {

        cReina REINA = new cReina();
        cRey REY = new cRey();
        cTorre_Blanco TORRE_B = new cTorre_Blanco();
        cTorre_Negro TORRE_N = new cTorre_Negro();
        cAlfil_Blanco ALFIL_B = new cAlfil_Blanco();
        cAlfil_Negro ALFIL_N = new cAlfil_Negro();
        cCaballo_Blanco CABALLO_B = new cCaballo_Blanco();
        cCaballo_Negro CABALLO_N = new cCaballo_Negro();

        public enum eReferencia { desocupado, atacado, rey = 2, torreB, torreN, caballoB, caballoN, alfilB, alfilN, reina, stop_moving, LEVE = 88, FATAL = 99 }
        public int TAM { get; set; }
        public int numColumna { get; set; }
        public int numFila { get; set; }

        public struct pos
        {
            public int fila;
            public int columna;
        };

        public int[,] tablero = new int[8, 8];
        public int[,] tablero_ataque = new int[8, 8];

        public matriz(int tam)
        {
            tablero = new int[tam, tam];
            this.TAM = tam;


            for (int i = 0; i < tam; i++)
            {
                for (int j = 0; j < tam; j++)
                {
                    tablero[i, j] = 0; //PONGO TODO EN CERO
                }
            }
        }


        public void ubico_piezas(int sol)
        {
            inicializo(tablero.GetLength(0));
            //como en la foto
            if (sol == 1)
            {
                tablero[1, 4] = (int)eReferencia.caballoN;
                tablero[3, 3] = (int)eReferencia.rey;
                tablero[3, 4] = (int)eReferencia.torreN;
                tablero[4, 1] = (int)eReferencia.caballoB;
                tablero[4, 3] = (int)eReferencia.reina;
                tablero[4, 4] = (int)eReferencia.alfilB;
                tablero[4, 5] = (int)eReferencia.alfilN;
                tablero[5, 5] = (int)eReferencia.torreB;
            }
            if (sol == 2)
            {
                tablero[2, 2] = (int)eReferencia.torreN;
                tablero[2, 3] = (int)eReferencia.alfilN;
                tablero[3, 3] = (int)eReferencia.alfilB;
                tablero[3, 4] = (int)eReferencia.torreB;
                tablero[3, 6] = (int)eReferencia.caballoN;
                tablero[4, 3] = (int)eReferencia.reina;
                tablero[4, 4] = (int)eReferencia.rey;
                tablero[6, 3] = (int)eReferencia.caballoB;
            }
            if (sol == 4)
            {
                //el tablero arranca vacio
                inicializo(tablero.GetLength(0));
            }
            return;
        }

        public void inicializo(int tam)
        {
            for (int i = 0; i < tam; i++)
            {
                for (int j = 0; j < tam; j++)
                {
                    tablero[i, j] = (int)eReferencia.desocupado;
                    tablero_ataque[i, i] = (int)eReferencia.desocupado;
                }
            }
        }

        public void pinta_pos_pieza(eReferencia tipo, int numFila, int numColumna)
        {
            pos aux = buscoPosPieza(tipo);

            if (aux.fila >= 0 && aux.columna >= 0)
            {
                if (numFila >= 0 && numFila < tablero.GetLength(0) && numColumna >= 0 && numColumna < tablero.GetLength(1))
                {
                    tablero[aux.fila, aux.columna] = 0; //desocupo
                    tablero[numFila, numColumna] = (int)tipo; //marco nueva pos
                }
            }
        }

        public bool limite_valido(eReferencia tipo, int numFila, int numColumna)
        {
            if (numColumna >= 0 && numColumna < tablero.GetLength(1) && numFila >= 0 && numFila < tablero.GetLength(0))
            {
                int casillero = tablero[numFila, numColumna];
                if ((casillero == (int)eReferencia.desocupado) || (casillero == (int)eReferencia.atacado))
                {
                    //CRITERIOS DE PODA

                    pos reina = buscoPosPieza(eReferencia.reina);
                    pos torreN = buscoPosPieza(eReferencia.torreN);
                    pos torreB = buscoPosPieza(eReferencia.torreB);
                    pos alfilN = buscoPosPieza(eReferencia.alfilN);
                    pos alfilB = buscoPosPieza(eReferencia.alfilB);

                    switch ((int)tipo)
                    {
                        case (int)eReferencia.rey:
                            if ((numFila == 0 && numColumna == 0) ||
                                (numFila == tablero.GetLength(0) - 1 && numColumna == tablero.GetLength(1) - 1) ||
                                (numFila == 0 && numColumna == tablero.GetLength(1) - 1) ||
                                (numFila == tablero.GetLength(0) - 1 && numColumna == 0))
                            {
                                // el rey no puede estar en los límites del tablero
                                return false;
                            }
                            break;
                        case (int)eReferencia.torreB:
                            if (numFila == reina.fila || numColumna == reina.columna ||
                                numFila == torreN.fila || numColumna == torreN.columna)
                            {
                                // torres no pueden estar en la misma fila/columna que otra torre o que la reina
                                return false;
                            }
                            break;
                        case (int)eReferencia.torreN:
                            if (numFila == reina.fila || numColumna == reina.columna ||
                                numFila == torreB.fila || numColumna == torreB.columna)
                            {
                                // torres no pueden estar en la misma fila/columna que otra torre o que la reina
                                return false;
                            }
                            break;
                        case (int)eReferencia.caballoB:
                            break;
                        case (int)eReferencia.caballoN:
                            break;
                        case (int)eReferencia.alfilB:
                            for (int i = 1; i < tablero.GetLength(0); i++)
                            {
                                if ((numFila + i == reina.fila && numColumna + i == reina.columna) ||
                                    (numFila + i == reina.fila && numColumna - i == reina.columna) ||
                                    (numFila - i == reina.fila && numColumna + i == reina.columna) ||
                                    (numFila - i == reina.fila && numColumna - i == reina.columna))
                                {
                                    // el alfil no puede estar en la misma diagonal que la reina
                                    return false;
                                }
                            }
                            break;
                        case (int)eReferencia.alfilN:
                            for (int i = 1; i < tablero.GetLength(0); i++)
                            {
                                if ((numFila + i == reina.fila && numColumna + i == reina.columna) ||
                                    (numFila + i == reina.fila && numColumna - i == reina.columna) ||
                                    (numFila - i == reina.fila && numColumna + i == reina.columna) ||
                                    (numFila - i == reina.fila && numColumna - i == reina.columna))
                                {
                                    // el alfil no puede estar en la misma diagonal que la reina
                                    return false;
                                }
                            }
                            break;
                        case (int)eReferencia.reina:
                            for (int i = 1; i < tablero.GetLength(0); i++)
                            {
                                if ((numFila + i == alfilB.fila && numColumna + i == alfilB.columna) ||
                                    (numFila + i == alfilB.fila && numColumna - i == alfilB.columna) ||
                                    (numFila - i == alfilB.fila && numColumna + i == alfilB.columna) ||
                                    (numFila - i == alfilB.fila && numColumna - i == alfilB.columna)
                                    ||
                                    (numFila + i == alfilN.fila && numColumna + i == alfilN.columna) ||
                                    (numFila + i == alfilN.fila && numColumna - i == alfilN.columna) ||
                                    (numFila - i == alfilN.fila && numColumna + i == alfilN.columna) ||
                                    (numFila - i == alfilN.fila && numColumna - i == alfilN.columna)
                                    ||
                                    (numFila == torreB.fila || numColumna == torreB.columna)
                                    ||
                                    (numFila == torreN.fila || numColumna == torreN.columna))
                                {
                                    // alfiles no puede estar en la misma diagonal que la reina
                                    // torres no pueden estar en la misma fila/columna que otra torre o que la reina
                                    return false;
                                }
                            }
                            break;
                    }

                    return true;
                }
            }
            return false; //fuera de los limites del tablero.
        }

        public pos buscoPosPieza(eReferencia tipo)
        {
            pos aux;
            for (int i = 0; i < tablero.GetLength(0); i++)
            {
                for (int j = 0; j < tablero.GetLength(0); j++)
                {
                    if (tablero[i, j] == (int)tipo)
                    {
                        aux.fila = i;
                        aux.columna = j;
                        return aux;
                    }
                }
            }

            aux.fila = -1;
            aux.columna = -1;
            return aux; //pos invalida 
        }

        public bool agregar(List<matriz> lista)
        {
            lista.Add(this);
            return true;
        }

        public void imprimirTablero()
        {
            string text = "";

            for (int i = 0; i < tablero.GetLength(0); i++)
            {
                for (int j = 0; j < tablero.GetLength(0); j++)
                {
                    if (tablero[i, j] < 10)
                        text += "0" + tablero[i, j].ToString("0") + "\t";
                    else
                        text += tablero[i, j].ToString("0") + "\t";

                }
                text += "\n";
            }

            Console.WriteLine(text);

            text = "";

            for (int i = 0; i < tablero.GetLength(0); i++)
            {
                for (int j = 0; j < tablero.GetLength(0); j++)
                {
                    if (tablero_ataque[i, j] < 10)
                        text += "0" + tablero_ataque[i, j].ToString("0") + "\t";
                    else
                        text += tablero_ataque[i, j].ToString("0") + "\t";


                }
                text += "\n";
            }
            Console.WriteLine(text);

        }

        public bool Existe(int cont_sol_enc, List<matriz> lista_soluciones)
        {
            int cont = 0;
            for (int k = 0; k < cont_sol_enc; k++)
            {
                for (int i = 0; i < this.TAM; i++)
                {
                    for (int j = 0; j < this.TAM; j++)
                    {

                        if (lista_soluciones[k].tablero[i, j] != this.tablero[i, j]) //si no se repite una solucion
                        {
                            cont++;
                            i = this.TAM;
                            j = this.TAM;
                        }
                    }

                }
            }
            if (cont == cont_sol_enc) //no se repitio la solucion
                return false; //no existe esta solcuion (...aun...)=> es valida!!!
            else
                return true; //solcion ya existente (repetida)
        }

        public bool Atacar(matriz tableroPIEZAS) //ataca con 01
        {
            //devuelve true si estan todas pintadas

            //posiciono piezas en el tablero de ataque

            for (int i = 0; i < tableroPIEZAS.TAM; i++)
            {
                for (int j = 0; j < tableroPIEZAS.TAM; j++)
                {
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.rey)
                        this.tablero_ataque[i, j] = (int)eReferencia.rey;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.torreB)
                        this.tablero_ataque[i, j] = (int)eReferencia.torreB;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.torreN)
                        this.tablero_ataque[i, j] = (int)eReferencia.torreN;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.caballoB)
                        this.tablero_ataque[i, j] = (int)eReferencia.caballoB;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.caballoN)
                        this.tablero_ataque[i, j] = (int)eReferencia.caballoN;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.alfilB)
                        this.tablero_ataque[i, j] = (int)eReferencia.alfilB;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.alfilN)
                        this.tablero_ataque[i, j] = (int)eReferencia.alfilN;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.reina)
                        this.tablero_ataque[i, j] = (int)eReferencia.reina;

                }
            }

            for (int i = 0; i < tableroPIEZAS.TAM; i++)
            {
                for (int j = 0; j < tableroPIEZAS.TAM; j++)
                {
                    if (this.tablero_ataque[i, j] == (int)eReferencia.rey)
                        REY.Atacar(this);
                    if (tableroPIEZAS.tablero_ataque[i, j] == (int)eReferencia.torreB)
                        TORRE_B.Atacar(this);
                    if (tableroPIEZAS.tablero_ataque[i, j] == (int)eReferencia.torreN)
                        TORRE_N.Atacar(this);
                    if (tableroPIEZAS.tablero_ataque[i, j] == (int)eReferencia.caballoB)
                        CABALLO_B.Atacar(this);
                    if (tableroPIEZAS.tablero_ataque[i, j] == (int)eReferencia.caballoN)
                        CABALLO_N.Atacar(this);
                    if (tableroPIEZAS.tablero_ataque[i, j] == (int)eReferencia.alfilB)
                        ALFIL_B.Atacar(this);
                    if (tableroPIEZAS.tablero_ataque[i, j] == (int)eReferencia.alfilN)
                        ALFIL_N.Atacar(this);
                    if (tableroPIEZAS.tablero_ataque[i, j] == (int)eReferencia.reina)
                        REINA.Atacar(this);
                }
            }

            bool ataquecompleto;
            ataquecompleto = true;


            for (int i = 0; i < tableroPIEZAS.TAM; i++)
            {
                for (int j = 0; j < tableroPIEZAS.TAM; j++)
                {
                    //si hay al menos un casillero desocupado no se ataco completamente
                    if (this.tablero_ataque[i, j] == (int)eReferencia.desocupado)
                        ataquecompleto = false;

                }
            }

            tablero_ataque = new int[8, 8];

            if (ataquecompleto == false)
                return false; //no se ataco todo el tablero
            else
                return true;

        }

        public void AtaqueFATAL(matriz tableroPIEZAS) //ataca con 99
        {

            for (int i = 0; i < tableroPIEZAS.TAM; i++)
            {
                for (int j = 0; j < tableroPIEZAS.TAM; j++)
                {
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.rey)
                        tablero_ataque[i, j] = (int)eReferencia.rey;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.torreB)
                        tablero_ataque[i, j] = (int)eReferencia.torreB;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.torreN)
                        tablero_ataque[i, j] = (int)eReferencia.torreN;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.caballoB)
                        tablero_ataque[i, j] = (int)eReferencia.caballoB;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.caballoN)
                        tablero_ataque[i, j] = (int)eReferencia.caballoN;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.alfilB)
                        tablero_ataque[i, j] = (int)eReferencia.alfilB;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.alfilN)
                        tablero_ataque[i, j] = (int)eReferencia.alfilN;
                    if (tableroPIEZAS.tablero[i, j] == (int)eReferencia.reina)
                        tablero_ataque[i, j] = (int)eReferencia.reina;

                }
            }


            for (int i = 0; i < this.TAM; i++)
            {
                for (int j = 0; j < this.TAM; j++)
                {
                    if (tablero_ataque[i, j] == (int)eReferencia.rey)
                        REY.AtaqueFATAL(this);
                    if (tablero_ataque[i, j] == (int)eReferencia.torreB)
                        TORRE_B.AtaqueFATAL(this);
                    if (tablero_ataque[i, j] == (int)eReferencia.torreN)
                        TORRE_N.AtaqueFATAL(this);
                    if (tablero_ataque[i, j] == (int)eReferencia.caballoB)
                        CABALLO_B.AtaqueFATAL(this);
                    if (tablero_ataque[i, j] == (int)eReferencia.caballoN)
                        CABALLO_N.AtaqueFATAL(this);
                    if (tablero_ataque[i, j] == (int)eReferencia.alfilB)
                        ALFIL_B.AtaqueFATAL(this);
                    if (tablero_ataque[i, j] == (int)eReferencia.alfilN)
                        ALFIL_N.AtaqueFATAL(this);
                    if (tablero_ataque[i, j] == (int)eReferencia.reina)
                        REINA.AtaqueFATAL(this);
                }
            }
        }
    } 
}