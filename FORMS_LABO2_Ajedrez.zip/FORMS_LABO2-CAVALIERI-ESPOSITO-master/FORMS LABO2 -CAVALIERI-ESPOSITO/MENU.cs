﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    public partial class MENU : Form
    {
        public MENU()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btnBuscarSoluciones_Click(object sender, EventArgs e)
        {

            List<matriz> Lista_Soluciones = Busqueda_de_soluciones();
            SOLUCIONES FormSoluciones = new SOLUCIONES(Lista_Soluciones, this, int.Parse(comboBox1.Text));
            FormSoluciones.Show();
            this.Hide();

        }

        List<matriz> Busqueda_de_soluciones()   //antes estaba con static 
        {
            int CANT_SOLUCIONES_BUSCAR = 0;
            if (int.TryParse(comboBox1.Text, out _))
                CANT_SOLUCIONES_BUSCAR = int.Parse(comboBox1.Text);

            cReina REINA = new cReina();
            cRey REY = new cRey();
            cTorre_Blanco TORRE_B = new cTorre_Blanco();
            cTorre_Negro TORRE_N = new cTorre_Negro();
            cAlfil_Blanco ALFIL_B = new cAlfil_Blanco();
            cAlfil_Negro ALFIL_N = new cAlfil_Negro();
            cCaballo_Blanco CABALLO_B = new cCaballo_Blanco();
            cCaballo_Negro CABALLO_N = new cCaballo_Negro();



            matriz tablero_aux = new matriz(8);
            matriz tableroATAQUES = new matriz(8);

            //pongo todo en 0
            tablero_aux.inicializo(8);
            tableroATAQUES.inicializo(8);


            int cont_soluciones_encontradas = 0;   //cantidad de soluciones encontradas distintas 


            //CREO LISTA DE SOLUCIONES Y LE AGREGO LAS DOS SOLUCIONES INICIALES
            List<matriz> lista_soluciones = new List<matriz>();

            for (int i = 0; i < 10; i++)
                lista_soluciones.Add(new matriz(8));


            //----------------------------------solucion 1----------------------------------------------

            lista_soluciones[0].ubico_piezas(1);   //agrego la primera solucion a la lista
            cont_soluciones_encontradas++;
            lista_soluciones[0].AtaqueFATAL(lista_soluciones[0]);  //agrego en la misma posicion el tablero con ataques

            //----------------------------------solucion 2----------------------------------------------

            lista_soluciones[1].ubico_piezas(2);
            cont_soluciones_encontradas++;
            lista_soluciones[1].AtaqueFATAL(lista_soluciones[1]);

            //--------------------------------------COMIENZA EL ATAQUE---------------------------------------------

            //Inicializo el tablero en alguna solucion y luego empiezo a mover
            Random r = new Random();
            int sol = (int)r.Next(1, 3);
            tablero_aux.ubico_piezas(sol);

            while (cont_soluciones_encontradas < CANT_SOLUCIONES_BUSCAR) // se hace hasta que haya 10 soluciones distintas
            {

                matriz.eReferencia tipo;
                tipo = matriz.eReferencia.rey;
                bool found_sol = false; //BRUNO


                do
                {
                    switch (tipo)
                    {
                        case matriz.eReferencia.rey:
                            REY.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.torreB:
                            TORRE_B.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;
                        case matriz.eReferencia.torreN:
                            TORRE_N.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.caballoB:
                            CABALLO_B.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.caballoN:
                            CABALLO_N.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.alfilB:
                            ALFIL_B.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.alfilN:
                            ALFIL_N.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        case matriz.eReferencia.reina:
                            REINA.Mover_random(tablero_aux);
                            if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                                found_sol = true;
                            tipo++;
                            break;

                        default:
                            tipo = matriz.eReferencia.rey;
                            break;
                    }

                } while (!found_sol);

                //si la solución es válida la guardo y sumo 1 al contador de soluciones
                cont_soluciones_encontradas++;

                lista_soluciones[cont_soluciones_encontradas - 1] = tablero_aux;

                lista_soluciones[cont_soluciones_encontradas - 1].AtaqueFATAL(lista_soluciones[cont_soluciones_encontradas - 1]);

                tablero_aux= Espejar(tablero_aux);
                if (tablero_aux.Atacar(tablero_aux) && !tablero_aux.Existe(cont_soluciones_encontradas, lista_soluciones))
                {
                    cont_soluciones_encontradas++;

                    lista_soluciones[cont_soluciones_encontradas - 1] = tablero_aux;

                    lista_soluciones[cont_soluciones_encontradas - 1].AtaqueFATAL(lista_soluciones[cont_soluciones_encontradas - 1]);

                }

                // busco otra sol de la cual partir
                tablero_aux = new matriz(8);
                r = new Random();
                sol = (int)r.Next(1, 3);
                tablero_aux.ubico_piezas(sol);


            }

            return lista_soluciones;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        public matriz Espejar(matriz tablero_aux)
        {
            matriz espejo = new matriz(8);

            for (int i = 0; i < tablero_aux.TAM; ++i)
            {
                for (int j = 0; j < tablero_aux.TAM; ++j) 
                {
                    //intercambio
                    espejo.tablero[i, j] = tablero_aux.tablero[i, 7 - j]; 
                    espejo.tablero[i, 7 - j] = tablero_aux.tablero[i, j];

                }
            }
            return espejo;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Analisis cuantitativo de la cota inferior: para obtener el mejor caso, analizamos el costo" +
                             "del programa desde que comienza el ataque, es decir desde que comenzamos a mover de forma" +
                             "aleatoria las piezas para encontrar UNA solucion. Luego lo vamos a multiplicar " +
                             "por la entrada que son los 1o tableros-solucion a encontrar. Entonces, según nuestro programa, la primera" +
                             "pieza en moverse es el rey. Por lo tanto, si el rey se mueve de forma tal que el tablero este" +
                             "atacado completamente, entonces solo haria falta mover una sola pieza para lograr encontrar una" +
                             "solucion. El rey entonces, entra a la funcion MoverRandom y se mueve de forma aleatoria. Además chequea" +
                             "si esa nueva posicion es valida (en el mejor de los casos la es), y retorna ture. Luego sale, ataca, es" +
                             "decir, pinta los ataques y como la solucion (mejor caso) no esta repetida, finalmente toma ese tablero" +
                             "como solucion valida." + "\n\n" +
                             "Entonces: " + "\n\n" +
                             "while (cont_soluciones_encontradas < CANT_SOLUCIONES_BUSCAR) vale 3\n" +
                             "2 asignaciones y busquedas de valores valen 2 cada uno = 4\n" +
                             "do{  } while (!found_sol) vale 2\n" +
                             "entra al switch (tipo) que vale 1\n" +
                             "entra al case matriz.eReferencia.rey que vale 1\n" +
                             "entra a REY.Mover_random(tablero_aux) que vale 4 porque hay asignaciones y llama a dos funciones\n" +
                             "chequea si la solucion es valida en if (tablero_aux.Atacar && !tablero_aux.Existe), vale 4" +
                             "entra al if y found_sol = true que vale 2 y sale del do while.\n\n" +
                             "Ahi termina el calculo de UN tablero. Entonces para 10 tableros (tamanio de la entrada n = 10) se multiplica " +
                             "ese costo por 10." +
                             "\n\n\n\n" +
                            "Analisis cualitativo de la cota superior: el peor caso se da cuando el programa " +
                            "se queda en un while constante porque no provee movimientos (aleatorios) satisfactorios" +
                            "que permitan que el tablero se vea atacado completamente. Además, existen 2 while, uno" +
                            "dentro del otro, donde el while externo, termina cuando se llega a las 10 soluciones." +
                            "mientras que el while interno termina cuando se encuentra una solucion para luego reubicar" +
                            "las piezas y seguir buscando la proxima solucion. Es por esto que cuanto mas tarde en moverse" +
                            "una pieza de forma optima, mas tardara el programa en salir del while interno, y luego del" +
                            "externo. Por eso es que optimizamos los movimientos de las piezas podando lo mas que se pueda" +
                            "para minimizar la ocurrencia del peor caso.", "Costo");
        }

        private void btnPODA_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Usamos el siguiente mecanismo: aplicar restricciones a la hora de mover las piezas," +
                            " mediante la función limite_valido, así el programa descarta rápidamente la opción " +
                            "de mover una pieza si su nueva posición no fuera óptima." + "\n\n\n" +

                            "Algunas de las mencionadas restricciones son:" + "\n\n" +

                            "Las Piezas pueden moverse una posición si la misma esta desocupada, o bien ya atacada." + "\n" +
                            "El Rey NO puede estar en los límites del tablero." + "\n" +
                            "Las Torres NO pueden estar en la misma fila / columna que otra Torre o que la Reina." + "\n" +
                            "Los Alfiles NO pueden estar en la misma diagonal que la Reina." + "\n\n\n" +

                            "A su vez, como el programa tardaba en encontrar las 10 soluciones, decidimos aplicar una Poda más, mediante la " +
                            "función Espejar, que como su nombre lo indica, cuando se encuentra una solución, esta se agrega a la lista, y " +
                            "luego es espejada.Esta nueva solución se chequea para comprobar que sea efectivamente otra solución no repetida," +
                            " y se agrega a la lista de soluciones.", "Criterios de Poda");
        }
    }
}
