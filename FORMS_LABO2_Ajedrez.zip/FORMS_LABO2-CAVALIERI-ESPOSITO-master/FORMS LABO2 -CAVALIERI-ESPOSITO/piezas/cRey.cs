﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    class cRey : cPiezas
    {
        public override void AtaqueFATAL(matriz tableroATAQUE)
        {
            #region GUARDO POS REY
            int fila_rey = 0;
            int columna_rey = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.rey)
                    {
                        fila_rey = i;
                        columna_rey = j;
                        break;
                    }
                }
            }


            #endregion

            #region COLUMNA 

            if (fila_rey + 1 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey] == (int)matriz.eReferencia.desocupado))
                tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey] = (int)matriz.eReferencia.FATAL;

            if (fila_rey - 1 >= 0 && (tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey] == (int)matriz.eReferencia.desocupado))
                tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey] = (int)matriz.eReferencia.FATAL;


            #endregion

            #region FILA

            if (columna_rey + 1 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_rey, columna_rey + 1] == (int)matriz.eReferencia.desocupado))
                tableroATAQUE.tablero_ataque[fila_rey, columna_rey + 1] = (int)matriz.eReferencia.FATAL;


            if (columna_rey - 1 >= 0 && (tableroATAQUE.tablero_ataque[fila_rey, columna_rey - 1] == (int)matriz.eReferencia.desocupado))
                tableroATAQUE.tablero_ataque[fila_rey, columna_rey - 1] = (int)matriz.eReferencia.FATAL;


            #endregion

            #region DIAGONALES     

            if (fila_rey + 1 < tableroATAQUE.TAM && columna_rey + 1 < tableroATAQUE.TAM && tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey + 1] == (int)matriz.eReferencia.desocupado)
                tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey + 1] = (int)matriz.eReferencia.FATAL;


            if (fila_rey - 1 >= 0 && columna_rey - 1 >= 0 && tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey - 1] == (int)matriz.eReferencia.desocupado)
                tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey - 1] = (int)matriz.eReferencia.FATAL;


            if (fila_rey + 1 < tableroATAQUE.TAM && columna_rey - 1 >= 0 && tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey - 1] == (int)matriz.eReferencia.desocupado)
                tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey - 1] = (int)matriz.eReferencia.FATAL;


            if (fila_rey - 1 >= 0 && columna_rey + 1 < tableroATAQUE.TAM && tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey + 1] == (int)matriz.eReferencia.desocupado)
                tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey + 1] = (int)matriz.eReferencia.FATAL;


            #endregion

        }
        public override void Atacar(matriz tableroATAQUE)
        {
            #region GUARDO POS REY
            int fila_rey = 0;
            int columna_rey = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.rey)
                    {
                        fila_rey = i;
                        columna_rey = j;
                        break;
                    }
                }
            }


            #endregion

            #region COLUMNA 

            if (fila_rey + 1 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey] == (int)matriz.eReferencia.desocupado))
                tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey] = (int)matriz.eReferencia.atacado;

            if (fila_rey - 1 >= 0 && (tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey] == (int)matriz.eReferencia.desocupado))
                tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey] = (int)matriz.eReferencia.atacado;


            #endregion

            #region FILA

            if (columna_rey + 1 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_rey, columna_rey + 1] == (int)matriz.eReferencia.desocupado))
                tableroATAQUE.tablero_ataque[fila_rey, columna_rey + 1] = (int)matriz.eReferencia.atacado;


            if (columna_rey - 1 >= 0 && (tableroATAQUE.tablero_ataque[fila_rey, columna_rey - 1] == (int)matriz.eReferencia.desocupado))
                tableroATAQUE.tablero_ataque[fila_rey, columna_rey - 1] = (int)matriz.eReferencia.atacado;


            #endregion

            #region DIAGONALES     

            if (fila_rey + 1 < tableroATAQUE.TAM && columna_rey + 1 < tableroATAQUE.TAM && tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey + 1] == (int)matriz.eReferencia.desocupado)
                tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey + 1] = (int)matriz.eReferencia.atacado;


            if (fila_rey - 1 >= 0 && columna_rey - 1 >= 0 && tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey - 1] == (int)matriz.eReferencia.desocupado)
                tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey - 1] = (int)matriz.eReferencia.atacado;


            if (fila_rey + 1 < tableroATAQUE.TAM && columna_rey - 1 >= 0 && tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey - 1] == (int)matriz.eReferencia.desocupado)
                tableroATAQUE.tablero_ataque[fila_rey + 1, columna_rey - 1] = (int)matriz.eReferencia.atacado;


            if (fila_rey - 1 >= 0 && columna_rey + 1 < tableroATAQUE.TAM && tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey + 1] == (int)matriz.eReferencia.desocupado)
                tableroATAQUE.tablero_ataque[fila_rey - 1, columna_rey + 1] = (int)matriz.eReferencia.atacado;


            #endregion

        }
        public override bool Mover_random(matriz tablero)
        {
            Random random = new Random();
            int fila = (int)random.Next(1, 7); //(3,6)
            int columna = (int)random.Next(1, 7); //(3,6)
            if (tablero.limite_valido(matriz.eReferencia.rey, fila, columna))
            {
                tablero.pinta_pos_pieza(matriz.eReferencia.rey, fila, columna);
                return true;
            }
            else
                return false;
        }
    }
}
