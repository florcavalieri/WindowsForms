﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    class cCaballo_Blanco : cPiezas
    {
        
        public override void AtaqueFATAL(matriz tableroATAQUE)
        {
            #region GUARDO POS CABALLO 
            int fila_caballo = 0;
            int columna_caballo = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.caballoB)
                    {
                        fila_caballo = i;
                        columna_caballo = j;
                        break;
                    }
                }
            }


            #endregion

            #region 'Ls' 

            if (columna_caballo >= 0 && columna_caballo < tableroATAQUE.TAM && fila_caballo >= 0 && fila_caballo < tableroATAQUE.TAM)
            {

                if (fila_caballo + 2 < tableroATAQUE.TAM && columna_caballo + 1 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_caballo + 2, columna_caballo + 1] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo + 2, columna_caballo + 1] = (int)matriz.eReferencia.FATAL;

                if (fila_caballo + 2 < tableroATAQUE.TAM && columna_caballo - 1 >= 0 && (tableroATAQUE.tablero_ataque[fila_caballo + 2, columna_caballo - 1] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo + 2, columna_caballo - 1] = (int)matriz.eReferencia.FATAL;

                if (fila_caballo - 2 >= 0 && columna_caballo + 1 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_caballo - 2, columna_caballo + 1] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo - 2, columna_caballo + 1] = (int)matriz.eReferencia.FATAL;

                if (fila_caballo - 2 >= 0 && columna_caballo - 1 >= 0 && (tableroATAQUE.tablero_ataque[fila_caballo - 2, columna_caballo - 1] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo - 2, columna_caballo - 1] = (int)matriz.eReferencia.FATAL;

                if (fila_caballo + 1 < tableroATAQUE.TAM && columna_caballo + 2 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_caballo + 1, columna_caballo + 2] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo + 1, columna_caballo + 2] = (int)matriz.eReferencia.FATAL;

                if (fila_caballo + 1 < tableroATAQUE.TAM && columna_caballo - 2 >= 0 && (tableroATAQUE.tablero_ataque[fila_caballo + 1, columna_caballo - 2] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo + 1, columna_caballo - 2] = (int)matriz.eReferencia.FATAL;

                if (fila_caballo - 1 >= 0 && columna_caballo + 2 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_caballo - 1, columna_caballo + 2] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo - 1, columna_caballo + 2] = (int)matriz.eReferencia.FATAL;

                if (fila_caballo - 1 >= 0 && columna_caballo - 2 >= 0 && (tableroATAQUE.tablero_ataque[fila_caballo - 1, columna_caballo - 2] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo - 1, columna_caballo - 2] = (int)matriz.eReferencia.FATAL;

            }

            #endregion
   
        }

        public override void Atacar(matriz tableroATAQUE)
        {
            #region GUARDO POS CABALLO 
            int fila_caballo = 0;
            int columna_caballo = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.caballoB)
                    {
                        fila_caballo = i;
                        columna_caballo = j;
                        break;
                    }
                }
            }


            #endregion

            #region 'Ls' 

            if (columna_caballo > 0 && columna_caballo < tableroATAQUE.TAM && fila_caballo > 0 && fila_caballo < tableroATAQUE.TAM)
            {

                if (fila_caballo + 2 < tableroATAQUE.TAM && columna_caballo + 1 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_caballo + 2, columna_caballo + 1] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo + 2, columna_caballo + 1] = (int)matriz.eReferencia.atacado;

                if (fila_caballo + 2 < tableroATAQUE.TAM && columna_caballo - 1 >= 0 && (tableroATAQUE.tablero_ataque[fila_caballo + 2, columna_caballo - 1] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo + 2, columna_caballo - 1] = (int)matriz.eReferencia.atacado;

                if (fila_caballo - 2 >= 0 && columna_caballo + 1 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_caballo - 2, columna_caballo + 1] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo - 2, columna_caballo + 1] = (int)matriz.eReferencia.atacado;

                if (fila_caballo - 2 >= 0 && columna_caballo - 1 >= 0 && (tableroATAQUE.tablero_ataque[fila_caballo - 2, columna_caballo - 1] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo - 2, columna_caballo - 1] = (int)matriz.eReferencia.atacado;

                if (fila_caballo + 1 < tableroATAQUE.TAM && columna_caballo + 2 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_caballo + 1, columna_caballo + 2] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo + 1, columna_caballo + 2] = (int)matriz.eReferencia.atacado;

                if (fila_caballo + 1 < tableroATAQUE.TAM && columna_caballo - 2 >= 0 && (tableroATAQUE.tablero_ataque[fila_caballo + 1, columna_caballo - 2] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo + 1, columna_caballo - 2] = (int)matriz.eReferencia.atacado;

                if (fila_caballo - 1 >= 0 && columna_caballo + 2 < tableroATAQUE.TAM && (tableroATAQUE.tablero_ataque[fila_caballo - 1, columna_caballo + 2] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo - 1, columna_caballo + 2] = (int)matriz.eReferencia.atacado;

                if (fila_caballo - 1 >= 0 && columna_caballo - 2 >= 0 && (tableroATAQUE.tablero_ataque[fila_caballo - 1, columna_caballo - 2] == (int)matriz.eReferencia.desocupado))
                    tableroATAQUE.tablero_ataque[fila_caballo - 1, columna_caballo - 2] = (int)matriz.eReferencia.atacado;

            }

            #endregion


        }
        public override bool Mover_random(matriz tablero)
        {
            Random random = new Random();
            int fila = (int)random.Next(1, 7); //(3,6)
            int columna = (int)random.Next(1, 7); //(3,6)
            if (tablero.limite_valido(matriz.eReferencia.caballoB, fila, columna))
            {
                tablero.pinta_pos_pieza(matriz.eReferencia.caballoB, fila, columna);
                return true;
            }
            else
                return false;
        }
    }
}

