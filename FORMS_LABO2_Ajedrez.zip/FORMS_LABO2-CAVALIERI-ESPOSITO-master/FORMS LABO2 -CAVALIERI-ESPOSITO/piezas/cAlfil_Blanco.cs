﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    class cAlfil_Blanco : cPiezas
    {
        public override void AtaqueFATAL(matriz tableroATAQUE)
        {
            #region GUARDO POS ALFIL
            int fila_alfil = 0;
            int columna_alfil = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.alfilB)
                    {
                        fila_alfil = i;
                        columna_alfil = j;
                        break;
                    }
                }
            }


            #endregion

            #region DIAGONAL 1
            for (int i = 1; i < tableroATAQUE.TAM; i++)
            {

                if (fila_alfil + i < tableroATAQUE.TAM && columna_alfil + i < tableroATAQUE.TAM)
                {
                    int posd1 = tableroATAQUE.tablero_ataque[fila_alfil + i, columna_alfil + i];

                    if (posd1 >= 2 && posd1 <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_alfil + i, columna_alfil + i] = (int)matriz.eReferencia.FATAL;
                }
            }


            #endregion

            #region DIAGONAL 2
            for (int i = 1; i < tableroATAQUE.TAM; i++)
            {

                if (fila_alfil - i >= 0 && columna_alfil - i >= 0)
                {
                    int posd2 = tableroATAQUE.tablero_ataque[fila_alfil - i, columna_alfil - i];

                    if (posd2 >= 2 && posd2 <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_alfil - i, columna_alfil - i] = (int)matriz.eReferencia.FATAL;
                }
            }

            #endregion

            #region DIAGONAL 3
            for (int i = 1; i < tableroATAQUE.TAM; i++)
            {

                if (fila_alfil + i < tableroATAQUE.TAM && columna_alfil - i >= 0)
                {
                    int posd3 = tableroATAQUE.tablero_ataque[fila_alfil + i, columna_alfil - i];

                    if (posd3 >= 2 && posd3 <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_alfil + i, columna_alfil - i] = (int)matriz.eReferencia.FATAL;
                }
            }

            #endregion

            #region DIAGONAL 4
            for (int i = 1; i < tableroATAQUE.TAM; i++)
            {
                if (fila_alfil - i >= 0 && columna_alfil + i < tableroATAQUE.TAM)
                {
                    int posd4 = tableroATAQUE.tablero_ataque[fila_alfil - i, columna_alfil + i];

                    if (posd4 >= 2 && posd4 <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_alfil - i, columna_alfil + i] = (int)matriz.eReferencia.FATAL;
                }
            }

            #endregion

        }

        public override void Atacar( matriz tableroATAQUE)
        {
            #region GUARDO POS ALFIL
            int fila_alfil = 0;
            int columna_alfil = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.alfilB)
                    {
                        fila_alfil = i;
                        columna_alfil = j;
                        break;
                    }
                }
            }


            #endregion

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                #region DIAGONAL 1

                if (fila_alfil + i < tableroATAQUE.TAM && columna_alfil + i < tableroATAQUE.TAM)
                {
                    int posd1 = tableroATAQUE.tablero_ataque[fila_alfil + i, columna_alfil + i];

                    if (posd1 == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_alfil + i, columna_alfil + i] = (int)matriz.eReferencia.atacado;
                }


                #endregion

                #region DIAGONAL 2

                if (fila_alfil - i >= 0 && columna_alfil - i >= 0)
                {
                    int posd2 = tableroATAQUE.tablero_ataque[fila_alfil - i, columna_alfil - i];

                    if (posd2 == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_alfil - i, columna_alfil - i] = (int)matriz.eReferencia.atacado;
                }

                #endregion

                #region DIAGONAL 3

                if (fila_alfil + i < tableroATAQUE.TAM && columna_alfil - i >= 0)
                {
                    int posd3 = tableroATAQUE.tablero_ataque[fila_alfil + i, columna_alfil - i];

                    if (posd3 == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_alfil + i, columna_alfil - i] = (int)matriz.eReferencia.atacado;
                }

                #endregion

                #region DIAGONAL 4

                if (fila_alfil - i >= 0 && columna_alfil + i < tableroATAQUE.TAM)
                {
                    int posd4 = tableroATAQUE.tablero_ataque[fila_alfil - i, columna_alfil + i];

                    if (posd4 == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_alfil - i, columna_alfil + i] = (int)matriz.eReferencia.atacado;
                }

                #endregion
            }

        }

        public override bool Mover_random(matriz tablero)
        {
            Random random = new Random();
            int fila = (int)random.Next(2, 6);
            int columna = (int)random.Next(2, 6);
            if (tablero.limite_valido(matriz.eReferencia.alfilB, fila, columna))
            {
                tablero.pinta_pos_pieza(matriz.eReferencia.alfilB, fila, columna);
                return true;
            }
            else
                return false;
        }
    }
}
