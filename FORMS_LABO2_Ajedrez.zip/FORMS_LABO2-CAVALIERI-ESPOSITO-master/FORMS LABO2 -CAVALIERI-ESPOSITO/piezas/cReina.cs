﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    class cReina : cPiezas
    {
        public override void AtaqueFATAL(matriz tableroATAQUE)
        {
            #region GUARDO POS REINA
            int fila_reina = 0;
            int columna_reina = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.reina)
                    {
                        fila_reina = i;
                        columna_reina = j;
                        break;
                    }
                }
            }


            #endregion

            #region COLUMNA 

            for (int i = (fila_reina+1); i < tableroATAQUE.TAM; i++)
            {

                if (i < tableroATAQUE.TAM)
                {
                    int posc = tableroATAQUE.tablero_ataque[i, columna_reina];

                    if (posc >= 2 && posc <= 9)
                        break; // sale del for -> nose si esta bienpero esa es la intencion
                    else
                        tableroATAQUE.tablero_ataque[i, columna_reina] = (int)matriz.eReferencia.FATAL;
                }

            }

            for (int i = (fila_reina-1); i >=0 ; i--)
            {

                if (i < tableroATAQUE.TAM)
                {
                    int posc = tableroATAQUE.tablero_ataque[i, columna_reina];

                    if (posc >= 2 && posc <= 9)
                        break; // sale del for -> nose si esta bienpero esa es la intencion
                    else
                        tableroATAQUE.tablero_ataque[i, columna_reina] = (int)matriz.eReferencia.FATAL;
                }

            }
            #endregion

            #region FILA 

            for (int i = (columna_reina + 1); i < tableroATAQUE.TAM; i++)
            {

                if (i < tableroATAQUE.TAM)
                {
                    int posf = tableroATAQUE.tablero_ataque[fila_reina, i];

                    if (posf >= 2 && posf <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_reina, i] = (int)matriz.eReferencia.FATAL;
                }
            }

            for (int i = (columna_reina - 1); i >=0 ; i--)
            {

                if (i < tableroATAQUE.TAM)
                {
                    int posf = tableroATAQUE.tablero_ataque[fila_reina, i];

                    if (posf >= 2 && posf <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_reina, i] = (int)matriz.eReferencia.FATAL;
                }
            }
            #endregion


            #region DIAGONAL 1
            for (int i = 1; i < tableroATAQUE.TAM; i++)
            {

                if (fila_reina + i < tableroATAQUE.TAM && columna_reina + i < tableroATAQUE.TAM)
                {
                    int posd1 = tableroATAQUE.tablero_ataque[fila_reina + i, columna_reina + i];

                    if (posd1 >= 2 && posd1 <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_reina + i, columna_reina + i] = (int)matriz.eReferencia.FATAL;
                }
            }

            
            #endregion


            #region DIAGONAL 2
            for (int i = 1; i < tableroATAQUE.TAM; i++)
                {

                if (fila_reina - i >= 0 && columna_reina - i >= 0)
                {
                    int posd2 = tableroATAQUE.tablero_ataque[fila_reina - i, columna_reina - i];

                    if (posd2 >= 2 && posd2 <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_reina - i, columna_reina - i] = (int)matriz.eReferencia.FATAL;
                }
            }
            
            #endregion


            #region DIAGONAL 3
            for (int i = 1; i < tableroATAQUE.TAM; i++)
            {

                if (fila_reina + i < tableroATAQUE.TAM && columna_reina - i >= 0)
                {
                    int posd3 = tableroATAQUE.tablero_ataque[fila_reina + i, columna_reina - i];

                    if (posd3 >= 2 && posd3 <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_reina + i, columna_reina - i] = (int)matriz.eReferencia.FATAL;
                }
            }
           
            #endregion

            #region DIAGONAL 4
            for (int i = 1; i < tableroATAQUE.TAM; i++)
            {
                if (fila_reina - i >=0 && columna_reina + i < tableroATAQUE.TAM)
                {
                    int posd4 = tableroATAQUE.tablero_ataque[fila_reina - i, columna_reina + i];

                    if (posd4 >= 2 && posd4 <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_reina - i, columna_reina + i] = (int)matriz.eReferencia.FATAL;
                }
            }
            
            #endregion

           

        }

        public override void Atacar(matriz tableroATAQUE)
        {
            #region GUARDO POS REINA
            int fila_reina = 0;
            int columna_reina = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.reina)
                    {
                        fila_reina = i;
                        columna_reina = j;
                        break;
                    }
                }
            }


            #endregion

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                #region COLUMNA 

                if (i < tableroATAQUE.TAM)
                {
                    int posc = tableroATAQUE.tablero_ataque[i, columna_reina];

                    if (posc == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[i, columna_reina] = (int)matriz.eReferencia.atacado;
                }

                #endregion

                #region FILA

                if (i < tableroATAQUE.TAM)
                {
                    int posf = tableroATAQUE.tablero_ataque[fila_reina, i];

                    if (posf == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_reina, i] = (int)matriz.eReferencia.atacado;
                }

                #endregion

                #region DIAGONAL 1

                if (fila_reina + i < tableroATAQUE.TAM && columna_reina + i < tableroATAQUE.TAM)
                {
                    int posd1 = tableroATAQUE.tablero_ataque[fila_reina + i, columna_reina + i];

                    if (posd1 == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_reina + i, columna_reina + i] = (int)matriz.eReferencia.atacado;
                }


                #endregion

                #region DIAGONAL 2

                if (fila_reina - i >= 0 && columna_reina - i >= 0)
                {
                    int posd2 = tableroATAQUE.tablero_ataque[fila_reina - i, columna_reina - i];

                    if (posd2 == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_reina - i, columna_reina - i] = (int)matriz.eReferencia.atacado;
                }

                #endregion

                #region DIAGONAL 3

                if (fila_reina + i < tableroATAQUE.TAM && columna_reina - i >= 0)
                {
                    int posd3 = tableroATAQUE.tablero_ataque[fila_reina + i, columna_reina - i];

                    if (posd3 == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_reina + i, columna_reina - i] = (int)matriz.eReferencia.atacado;
                }

                #endregion

                #region DIAGONAL 4

                if (fila_reina - i >= 0 && columna_reina + i < tableroATAQUE.TAM)
                {
                    int posd4 = tableroATAQUE.tablero_ataque[fila_reina - i, columna_reina + i];

                    if (posd4 == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_reina - i, columna_reina + i] = (int)matriz.eReferencia.atacado;
                }

                #endregion

            }
        }

        public override bool Mover_random(matriz tablero)
        {
            Random random = new Random();
            int fila = (int)random.Next(3, 5); // nosotras: (3,6)
            int columna = (int)random.Next(3, 5); //(3,6)
            if (tablero.limite_valido(matriz.eReferencia.reina, fila, columna))
            {
                tablero.pinta_pos_pieza(matriz.eReferencia.reina, fila, columna);
                return true;
            }
            else
                return false;
        }

    }
}
