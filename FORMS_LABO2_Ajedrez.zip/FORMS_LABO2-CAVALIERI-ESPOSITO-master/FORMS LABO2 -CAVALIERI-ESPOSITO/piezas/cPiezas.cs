﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    abstract class cPiezas
    {
        public abstract bool Mover_random(matriz tableroP);

        public abstract void AtaqueFATAL( matriz tableroATAQUE);

        public abstract void Atacar(matriz t_ataque);


    }
}
