﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FORMS_LABO2__CAVALIERI_ESPOSITO
{
    class cTorre_Blanco : cPiezas
    {
        public override void AtaqueFATAL(matriz tableroATAQUE)
        {


            #region GUARDO POS TORRE
            int fila_torre = 0;
            int columna_torre = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.torreB)
                    {
                        fila_torre = i;
                        columna_torre = j;
                        break;
                    }
                }
            }


            #endregion

            #region COLUMNA 

            for (int i = (fila_torre + 1); i < tableroATAQUE.TAM; i++)
            {

                if (i < tableroATAQUE.TAM)
                {
                    int posc = tableroATAQUE.tablero_ataque[i, columna_torre];

                    if (posc >= 2 && posc <= 9)
                        break; // sale del for -> nose si esta bienpero esa es la intencion
                    else
                        tableroATAQUE.tablero_ataque[i, columna_torre] = (int)matriz.eReferencia.FATAL;
                }

            }

            for (int i = (fila_torre - 1); i >= 0; i--)
            {

                if (i < tableroATAQUE.TAM)
                {
                    int posc = tableroATAQUE.tablero_ataque[i, columna_torre];

                    if (posc >= 2 && posc <= 9)
                        break; // sale del for -> nose si esta bienpero esa es la intencion
                    else
                        tableroATAQUE.tablero_ataque[i, columna_torre] = (int)matriz.eReferencia.FATAL;
                }

            }
            #endregion

            #region FILA 

            for (int i = (columna_torre + 1); i < tableroATAQUE.TAM; i++)
            {

                if (i < tableroATAQUE.TAM)
                {
                    int posf = tableroATAQUE.tablero_ataque[fila_torre, i];

                    if (posf >= 2 && posf <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_torre, i] = (int)matriz.eReferencia.FATAL;
                }
            }

            for (int i = (columna_torre - 1); i >= 0; i--)
            {

                if (i < tableroATAQUE.TAM)
                {
                    int posf = tableroATAQUE.tablero_ataque[fila_torre, i];

                    if (posf >= 2 && posf <= 9)
                        break;
                    else
                        tableroATAQUE.tablero_ataque[fila_torre, i] = (int)matriz.eReferencia.FATAL;
                }
            }
            #endregion

            
        }
        public override void Atacar( matriz tableroATAQUE)
        {
            #region GUARDO POS TORRE
            int fila_torre = 0;
            int columna_torre = 0;

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                for (int j = 0; j < tableroATAQUE.TAM; j++)
                {
                    if (tableroATAQUE.tablero_ataque[i, j] == (int)matriz.eReferencia.torreB)
                    {
                        fila_torre = i;
                        columna_torre = j;
                        break;
                    }
                }
            }


            #endregion

            for (int i = 0; i < tableroATAQUE.TAM; i++)
            {
                #region COLUMNA 

                if (i < tableroATAQUE.TAM)
                {
                    int posc = tableroATAQUE.tablero_ataque[i, columna_torre];

                    if (posc == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[i, columna_torre] = (int)matriz.eReferencia.atacado;
                }

                #endregion

                #region FILA

                if (i < tableroATAQUE.TAM)
                {
                    int posf = tableroATAQUE.tablero_ataque[fila_torre, i];

                    if (posf == (int)matriz.eReferencia.desocupado)
                        tableroATAQUE.tablero_ataque[fila_torre, i] = (int)matriz.eReferencia.atacado;
                }

                #endregion
            }
        }
        public override bool Mover_random(matriz tablero)
        {

            int fila = 0;
            int columna = 0;
            if (tablero.limite_valido(matriz.eReferencia.torreB, fila, columna))
            {
                tablero.pinta_pos_pieza(matriz.eReferencia.torreB, fila, columna);
                return true;
            }
            else
                return false;
        }
    }
}
